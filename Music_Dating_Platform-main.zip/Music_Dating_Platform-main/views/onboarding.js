const form = document.getElementById("onboardingForm");



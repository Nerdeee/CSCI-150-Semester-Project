# Music_Dating_Platform
Main branch for Cadence - a music dating platform

To run the site, clone the repo or download the repo's zip file. From there, you will want ot make sure that you have the LTS (Long Term Support) of NodeJS installed, which can be found here:
https://nodejs.org/en

Once installed, run the following command in your terminal where the repo folder is located: npm init
This command will install all of the required dependencies for the program to run.

To run the server, just type "nodemon server" into your terminal and the server will start up.


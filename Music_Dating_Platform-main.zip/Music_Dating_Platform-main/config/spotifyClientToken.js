const clientToken = 'f77cef6b629d48bbb0ba6bbbbff7d7d8';

export default clientToken;